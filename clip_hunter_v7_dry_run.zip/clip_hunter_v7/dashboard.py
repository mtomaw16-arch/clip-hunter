"""Mobile dashboard. Place behind HTTPS reverse proxy, protect using DASHBOARD_PASSWORD."""
import os, secrets
from collections import defaultdict
from datetime import datetime, timezone
from functools import wraps
from flask import Flask, jsonify, render_template, request, Response
from dotenv import load_dotenv
from store import connect
load_dotenv()
app=Flask(__name__)
PASSWORD=os.getenv('DASHBOARD_PASSWORD','')
if not PASSWORD:
    raise RuntimeError('Set DASHBOARD_PASSWORD in .env before starting the dashboard')

def protect(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        a=request.authorization
        if not a or not secrets.compare_digest(a.password or '',PASSWORD):
            return Response('Authentication required',401,{'WWW-Authenticate':'Basic realm="Clip Hunter"'})
        return fn(*args,**kwargs)
    return wrapper

@app.get('/')
@protect
def home(): return render_template('index.html')

@app.get('/api/clips')
@protect
def clips():
    with connect() as db:
        rows=[dict(r) for r in db.execute('SELECT * FROM clips ORDER BY ts DESC,id DESC LIMIT 500').fetchall()]
    return jsonify(rows)

@app.post('/api/clips/<int:clip_id>/review')
@protect
def review(clip_id):
    with connect() as db:
        row=db.execute('SELECT reviewed FROM clips WHERE id=?',(clip_id,)).fetchone()
        if row is None:return jsonify({'error':'Not found'}),404
        new=0 if row['reviewed'] else 1
        db.execute('UPDATE clips SET reviewed=? WHERE id=?',(new,clip_id));db.commit()
    return jsonify({'id':clip_id,'reviewed':new})

@app.post('/api/clips/<int:clip_id>/performance')
@protect
def performance(clip_id):
    values=request.get_json(silent=True) or {}
    try:
        posted=bool(values.get('posted', False))
        platform=str(values.get('platform',''))[:40]
        post_url=str(values.get('post_url',''))[:500]
        views=int(values.get('views',0))
        earnings=float(values.get('earnings',0))
        notes=str(values.get('notes',''))[:1000]
        if views<0 or earnings<0 or views>10**12 or earnings>10**9:raise ValueError()
        if post_url and not post_url.startswith(('https://','http://')):raise ValueError()
    except (TypeError, ValueError):
        return jsonify({'error':'Invalid performance data'}),400
    with connect() as db:
        row=db.execute('SELECT id FROM clips WHERE id=?',(clip_id,)).fetchone()
        if row is None:return jsonify({'error':'Not found'}),404
        db.execute('UPDATE clips SET posted=?,platform=?,post_url=?,views=?,earnings=?,notes=? WHERE id=?',
                   (int(posted),platform,post_url,views,earnings,notes,clip_id))
        db.commit()
    return jsonify({'ok':True})

@app.get('/api/activity')
@protect
def activity():
    with connect() as db:
        return jsonify([dict(r) for r in db.execute('SELECT * FROM event_log ORDER BY id DESC LIMIT 200')])

@app.get('/api/stats')
@protect
def stats():
    with connect() as db:
        d=db.execute('''SELECT count(*) total, sum(case when status='ready' then 1 else 0 end) ready,
                   sum(case when score>=85 and status='ready' then 1 else 0 end) high,
                   sum(case when reviewed=1 then 1 else 0 end) reviewed,
                   count(distinct group_id) highlights
                   FROM clips''').fetchone()
    result=dict(d)
    with connect() as db:
        result['posted']=db.execute('SELECT COUNT(*) FROM clips WHERE posted=1').fetchone()[0]
        result['views']=db.execute('SELECT COALESCE(SUM(views),0) FROM clips').fetchone()[0]
        result['earnings']=db.execute('SELECT COALESCE(SUM(earnings),0) FROM clips').fetchone()[0]
    return jsonify(result)

if __name__=='__main__':
    app.run(host=os.getenv('DASHBOARD_HOST','127.0.0.1'),port=int(os.getenv('DASHBOARD_PORT','8080')),debug=False)
