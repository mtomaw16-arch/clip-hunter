"""Twitch live-chat-triggered clip bot. No channel editor permission required."""
import asyncio, collections, json, logging, os, re, sqlite3, time
from pathlib import Path
from datetime import datetime, timezone
from store import connect
from detection import Detector

import aiohttp
import websockets
from dotenv import load_dotenv

load_dotenv()
CLIENT_ID = os.environ['TWITCH_CLIENT_ID']
CLIENT_SECRET = os.environ['TWITCH_CLIENT_SECRET']
CHANNEL = os.environ['TWITCH_CHANNEL'].lower().lstrip('@')
DISCORD = os.getenv('DISCORD_TOP_WEBHOOK_URL', os.getenv('DISCORD_WEBHOOK_URL', ''))
DISCORD_ALL = os.getenv('DISCORD_ALL_WEBHOOK_URL', '')
DISCORD_REPORT = os.getenv('DISCORD_REPORT_WEBHOOK_URL', DISCORD)
SPIKE_MULT = float(os.getenv('SPIKE_MULTIPLIER', '2'))
SPIKE_MIN = int(os.getenv('SPIKE_MIN_MESSAGES', '4'))
SPIKE_USERS = int(os.getenv('SPIKE_MIN_UNIQUE_USERS', '3'))
KEYWORD_USERS = int(os.getenv('KEYWORD_MIN_UNIQUE_USERS', '4'))
DURATION = max(5, min(60, float(os.getenv('CLIP_DURATION', '60'))))
DRY_RUN = os.getenv('DRY_RUN', 'true').strip().lower() in ('true', '1', 'yes', 'on')
POST_TRIGGER_SECONDS = max(0, float(os.getenv('POST_TRIGGER_SECONDS', '15')))  # approximate 45-before / 15-after targeting
COOLDOWN = int(os.getenv('COOLDOWN_SECONDS', '30'))
CONTINUOUS_INTERVAL = max(15, int(os.getenv('CONTINUOUS_CLIP_INTERVAL_SECONDS', '20')))
EVENT_GRACE = max(5, int(os.getenv('EVENT_GRACE_SECONDS', '12')))
KEYWORDS = [x.strip().casefold() for x in os.getenv('KEYWORDS', 'clip that,wtf,no way').split(',') if x.strip()]
TOKENS = Path('tokens.json')
log = logging.getLogger('clip_hunter')

class Bot:
    def __init__(self):
        self.tokens = json.loads(TOKENS.read_text())
        self.http = None
        self.bot_id = None
        self.channel_id = None
        self.live = False
        self.detector = Detector(SPIKE_MULT, KEYWORD_USERS, KEYWORDS, SPIKE_MIN, SPIKE_USERS)
        self.last_trigger = 0
        self.last_signal = 0
        self.active_highlight = False
        self.last_clip = None
        self.db = connect()
        self.group_id = int(self.db.execute('SELECT COALESCE(MAX(id),0) FROM highlights').fetchone()[0])
        self.pending_tasks = set()
        self.last_clip_by_group = {}
        self.discord_lock = asyncio.Lock()

    def headers(self):
        return {'Client-Id': CLIENT_ID, 'Authorization': 'Bearer ' + self.tokens['access_token']}

    async def refresh(self):
        async with self.http.post('https://id.twitch.tv/oauth2/token', data={
            'grant_type': 'refresh_token', 'refresh_token': self.tokens['refresh_token'],
            'client_id': CLIENT_ID, 'client_secret': CLIENT_SECRET}) as resp:
            response = await resp.text()
            if resp.status != 200: raise RuntimeError(f'OAuth refresh failed ({resp.status}): {response}')
            self.tokens.update(json.loads(response))
            TOKENS.write_text(json.dumps(self.tokens, indent=2))
            try: TOKENS.chmod(0o600)
            except OSError: pass

    async def api(self, method, path, *, params=None, payload=None):
        url = 'https://api.twitch.tv/helix/' + path
        for attempt in range(2):
            async with self.http.request(method, url, params=params, json=payload, headers=self.headers()) as r:
                content = await r.text()
                if r.status == 401 and attempt == 0:
                    await self.refresh(); continue
                if r.status >= 400: raise RuntimeError(f'{method} {path}: HTTP {r.status}: {content[:400]}')
                return json.loads(content) if content else {}

    async def setup(self):
        # Refresh proactively on startup; this also tests token health.
        await self.refresh()
        ids = await self.api('GET', 'users', params=[('login', CHANNEL)])
        if not ids['data']: raise RuntimeError('Channel not found: ' + CHANNEL)
        self.channel_id = ids['data'][0]['id']
        me = await self.api('GET', 'users')
        self.bot_id = me['data'][0]['id']
        await self.check_live()
        log.info('Monitoring %s as user %s. Live=%s. DRY_RUN=%s', CHANNEL, self.bot_id, self.live, DRY_RUN)

    async def check_live(self):
        result = await self.api('GET', 'streams', params={'user_id': self.channel_id})
        was_live = self.live
        self.live = bool(result['data'])
        if not self.live:
            self.detector.events.clear()
            self.active_highlight = False
            self.last_signal = 0
        if was_live != self.live: log.info('Stream state changed: %s', 'LIVE' if self.live else 'OFFLINE')

    async def subscribe(self, session_id):
        subscriptions = [
            ('stream.online', {'broadcaster_user_id': self.channel_id}),
            ('stream.offline', {'broadcaster_user_id': self.channel_id}),
            ('channel.chat.message', {'broadcaster_user_id': self.channel_id, 'user_id': self.bot_id}),
        ]
        for typ, condition in subscriptions:
            await self.api('POST', 'eventsub/subscriptions', payload={
                'type': typ, 'version': '1', 'condition': condition,
                'transport': {'method': 'websocket', 'session_id': session_id}
            })
        log.info('Subscribed to stream and chat events')

    def record(self, reason, score, clip_id, url, status, edit_url='', thumbnail='', group_id=None, ratio=0, keyword_users=0, discord_status='pending', trigger_words='', triggered_at=''):
        self.db.execute('''INSERT INTO clips(reason, score, clip_id, url, status, edit_url, thumbnail_url, group_id, spike_ratio, keyword_users, discord_status, trigger_words, triggered_at)
                           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                        (reason, score, clip_id, url, status, edit_url, thumbnail, group_id, ratio, keyword_users, discord_status, trigger_words, triggered_at))
        self.db.commit()

    def log_event(self, kind, desc):
        self.db.execute('INSERT INTO event_log(event_type,description) VALUES (?,?)',(kind,desc))
        self.db.commit()

    async def discord_request(self, webhook, payload, message_id=None):
        if not webhook:return None
        url=webhook.rstrip('/')
        if message_id:
            url += '/messages/' + str(message_id)
            method='PATCH'
        else:
            url += ('&' if '?' in url else '?') + 'wait=true'
            method='POST'
        try:
            async with self.http.request(method,url,json=payload,timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status not in (200,201,204):
                    log.warning('Discord %s response HTTP %s',method,resp.status)
                    return None
                data=await resp.json(content_type=None) if resp.status!=204 else {}
                return data.get('id') or message_id or 'sent'
        except Exception as exc:
            log.warning('Discord notification failed: %s',exc)
            return None

    async def send_discord(self, content, webhook=None):
        return 'sent' if await self.discord_request(webhook or DISCORD, {'content':content,'allowed_mentions':{'parse':[]}}) else 'failed'

    async def notify_clip(self, group_id, score, reason, ratio, words, url):
        # Every ready clip goes to #all-clips. High-priority event gets ONE
        # editable top-clips message; later clips amend it without new pings.
        if DISCORD_ALL:
            await self.discord_request(DISCORD_ALL,{'content':f'🎬 **{CHANNEL}** · Highlight #{group_id} · {score}/100 · {reason}\n{url}', 'allowed_mentions':{'parse':[]}})
        if not DISCORD:return 'disabled'
        best=self.db.execute('SELECT best_score FROM highlights WHERE id=?',(group_id,)).fetchone()
        best_score=max(score,best['best_score'] if best else 0)
        if best_score<int(os.getenv('DISCORD_MIN_SCORE','85')):return 'below_threshold'
        row=self.db.execute('SELECT discord_message_id FROM highlights WHERE id=?',(group_id,)).fetchone()
        message_id=row['discord_message_id'] if row else None
        rows=self.db.execute("SELECT url FROM clips WHERE group_id=? AND status='ready' ORDER BY id",(group_id,)).fetchall()
        links=[r['url'] for r in rows if r['url']]
        # Include newest link if saved after this call's query (should not happen).
        if url not in links:links.append(url)
        content=(f'🔥 **{CHANNEL} · Highlight #{group_id}** · Best score {best_score}/100\n'
                 f'**Trigger:** {reason} | {ratio:.1f}× chat | {", ".join(words[:5]) or "activity"}\n'
                 + '\n'.join(f'{i+1}. {u}' for i,u in enumerate(links[-12:])))
        if len(content)>1900: content=content[:1900]
        result=await self.discord_request(DISCORD,{'content':content,'allowed_mentions':{'parse':[]}},message_id)
        if result and result!='sent' and not message_id:
            self.db.execute('UPDATE highlights SET discord_message_id=? WHERE id=?',(str(result),group_id));self.db.commit()
        return 'sent' if result else 'failed'

    async def daily_summary(self):
        # UTC daily digest; only generated on days with at least one completed clip.
        while True:
            await asyncio.sleep(60)
            if not DISCORD_REPORT: continue
            today = datetime.now(timezone.utc).strftime('%Y-%m-%d')
            hour = datetime.now(timezone.utc).hour
            if hour < int(os.getenv('DISCORD_DAILY_SUMMARY_UTC_HOUR','20')): continue
            state = self.db.execute('SELECT val FROM app_state WHERE key=?', ('last_daily_summary',)).fetchone()
            if state and state['val']==today: continue
            stats = self.db.execute('''SELECT COUNT(*) total, SUM(CASE WHEN score>=85 THEN 1 ELSE 0 END) high,
                        COUNT(DISTINCT group_id) highlights FROM clips WHERE date(ts)=? AND status='ready' ''',(today,)).fetchone()
            if not stats['total']: continue
            tops=self.db.execute('''SELECT url,score FROM clips WHERE date(ts)=? AND status='ready' ORDER BY score DESC LIMIT 3''',(today,)).fetchall()
            msg=(f'📊 **Clip Hunter daily summary (UTC): {today}**\n'
                 f'Clips: {stats["total"]} | High priority: {stats["high"] or 0} | Highlight groups: {stats["highlights"]}\n'
                 + '\n'.join(f'• {r["score"]}/100 — {r["url"]}' for r in tops))
            result=await self.send_discord(msg, DISCORD_REPORT)
            if result=='sent':
                self.db.execute('INSERT OR REPLACE INTO app_state(key,val) VALUES (?,?)',('last_daily_summary',today));self.db.commit()


    async def delayed_clip(self, reason, score, ratio, word_count, triggered_at, group_id, words):
        """Wait until after the chat spike before requesting a backward-looking live clip.

        Twitch chooses the final placement. A viewer token cannot enforce exact offsets.
        Use an absolute time so delayed scheduling doesn't accumulate additional drift.
        """
        await asyncio.sleep(max(0, triggered_at + POST_TRIGGER_SECONDS - time.time()))
        if not self.live:
            log.info('Skipping scheduled clip: stream went offline')
            return
        log.info('Requesting clip %.1fs after detected reaction', time.time() - triggered_at)
        if DRY_RUN:
            self.record(reason, score, '', '', 'dry_run', group_id=group_id,
                        ratio=ratio, keyword_users=word_count, discord_status='disabled',
                        trigger_words=','.join(words),
                        triggered_at=datetime.fromtimestamp(triggered_at, timezone.utc).isoformat())
            self.log_event('dry_run_clip', f'Would clip: highlight #{group_id}, score {score}, {reason}, words={words}')
            log.info('DRY RUN: Would create clip for highlight #%s (score=%s, ratio=%.1f, keywords=%s)',
                     group_id, score, ratio, words)
            return
        await self.clip(reason, score, ratio, word_count, group_id, words, triggered_at)

    async def clip(self, reason, score, ratio, word_count, group_id, words, triggered_at):
        try:
            title = f'{CHANNEL} highlight ({reason})'
            response = await self.api('POST', 'clips', params={
                'broadcaster_id': self.channel_id, 'duration': DURATION, 'title': title
            })
            data = response['data'][0]
            clip_id = data['id']
            edit_url = data.get('edit_url', '')
            log.info('Clip requested: %s (%s, score %s)', clip_id, reason, score)
            for _ in range(12):
                await asyncio.sleep(5)
                result = await self.api('GET', 'clips', params={'id': clip_id})
                if result.get('data'):
                    clip_data = result['data'][0]
                    url = clip_data['url']
                    thumbnail = clip_data.get('thumbnail_url','')
                    # Send only high-priority alerts, avoid clutter during sustained events.
                    self.record(reason, score, clip_id, url, 'ready', edit_url, thumbnail, group_id, ratio, word_count, 'pending', ','.join(words), datetime.fromtimestamp(triggered_at, timezone.utc).isoformat())
                    async with self.discord_lock:
                        sent = await self.notify_clip(group_id,score,reason,ratio,words,url)
                    self.db.execute('UPDATE clips SET discord_status=? WHERE clip_id=?',(sent,clip_id));self.db.commit()
                    log.info('Clip ready: %s', url)
                    return
            self.record(reason, score, clip_id, '', 'unconfirmed', edit_url, group_id=group_id, ratio=ratio, keyword_users=word_count)
            log.warning('Clip unconfirmed after 60s: %s', clip_id)
        except Exception as e:
            self.record(reason, score, '', '', 'failed', group_id=group_id, ratio=ratio, keyword_users=word_count)
            log.error('Clip failed: %s', e)

    async def notification(self, packet):
        typ = packet['payload']['subscription']['type']
        event = packet['payload']['event']
        if typ == 'stream.online':
            self.live = True
            self.detector.events.clear()
            self.active_highlight = False
            self.last_signal = 0
            log.info('Stream online')
        elif typ == 'stream.offline':
            self.live = False
            self.detector.events.clear()
            self.active_highlight = False
            self.last_signal = 0
            log.info('Stream offline')
        elif typ == 'channel.chat.message' and self.live:
            now=time.time()
            user=event.get('chatter_user_id') or event.get('chatter_user_login')
            text=event.get('message',{}).get('text','')
            detection=self.detector.add(now,user,text)
            # Signals expire even in quiet chat; ticks also end highlights.
            self.expire_highlight(now)
            if not detection:return
            self.last_signal=now
            continuing=self.active_highlight
            if not continuing:
                # Normal cooldown is applied between separate highlights.
                if now-self.last_trigger<COOLDOWN:return
                self.active_highlight=True
                self.group_id+=1
                self.db.execute('INSERT INTO highlights(id,best_score,last_signal) VALUES (?,?,?)',
                                (self.group_id,detection.score,now));self.db.commit()
                self.log_event('highlight_started',f'Group {self.group_id} · {detection.kind}')
            else:
                self.db.execute('UPDATE highlights SET best_score=MAX(best_score,?),last_signal=? WHERE id=?',
                                (detection.score,now,self.group_id));self.db.commit()
            interval=CONTINUOUS_INTERVAL if continuing else COOLDOWN
            if now-self.last_trigger<interval:return
            self.last_trigger=now
            self.log_event('trigger',f'Group {self.group_id}, score {detection.score}, {detection.kind}')
            task=asyncio.create_task(self.delayed_clip(detection.kind,detection.score,detection.ratio,
                                  detection.keyword_users,now,self.group_id,detection.matches))
            self.pending_tasks.add(task)
            task.add_done_callback(self.pending_tasks.discard)

    def expire_highlight(self, now):
        if self.active_highlight and now-self.last_signal>EVENT_GRACE:
            self.active_highlight=False
            self.db.execute("UPDATE highlights SET status='ended', ended_at=CURRENT_TIMESTAMP WHERE id=?",(self.group_id,));self.db.commit()
            self.log_event('highlight_ended',f'Group {self.group_id}')

    async def run_socket(self):
        target = 'wss://eventsub.wss.twitch.tv/ws'
        while True:
            try:
                async with websockets.connect(target, ping_interval=20, ping_timeout=20) as ws:
                    reconnect = None
                    async for raw in ws:
                        packet = json.loads(raw)
                        kind = packet.get('metadata', {}).get('message_type')
                        if kind == 'session_welcome':
                            if target == 'wss://eventsub.wss.twitch.tv/ws':
                                await self.subscribe(packet['payload']['session']['id'])
                            # Twitch retains subscriptions for session_reconnect URLs.
                        elif kind == 'session_notification':
                            await self.notification(packet)
                        elif kind == 'session_reconnect':
                            reconnect = packet['payload']['session']['reconnect_url']
                            break
                        elif kind == 'revocation':
                            log.error('Subscription revoked: %s', packet['payload'])
                    target = reconnect or 'wss://eventsub.wss.twitch.tv/ws'
            except Exception as e:
                log.error('WebSocket error: %s', e)
                target = 'wss://eventsub.wss.twitch.tv/ws'
                await asyncio.sleep(5)

    async def periodic_check(self):
        while True:
            await asyncio.sleep(10)
            self.expire_highlight(time.time())
            try:
                if int(time.time()) % 300 < 10: await self.check_live()
            except Exception as e: log.warning('Live check failed: %s', e)

    async def start(self):
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=25)) as http:
            self.http = http
            await self.setup()
            await asyncio.gather(self.run_socket(), self.periodic_check(), self.daily_summary())

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    asyncio.run(Bot().start())
