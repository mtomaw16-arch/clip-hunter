# Clip Hunter v7 — dry run first

**Default: `DRY_RUN=true`.** The bot still authenticates to Twitch and monitors TheSketchReal's live chat, but it does not request Twitch clips or send Discord notifications. Every would-be clip is saved to `clips.db` with status `dry_run`; an event is also added to `event_log` and the terminal log. The saved entries represent trigger times and scores, **not actual video clips or Twitch URLs**.

## Steps on a trusted PC or VPS

1. Extract the ZIP, install Python 3.11+, and run `python -m pip install -r requirements.txt`.
2. Copy `.env.example` to `.env`. Keep `DRY_RUN=true` and `TWITCH_CHANNEL=thesketchreal`. Fill in the Twitch client ID and secret, then use `python auth.py` to authorize your own viewer account. Do not share `.env`, `tokens.json`, or webhook URLs.
3. Start with `python bot.py`. It monitors the channel when live. Let it run during a stream; no Twitch clips will be created.
4. View detection logs in the terminal or query `clips.db` for `status='dry_run'`. Example command: `python -c "import sqlite3; db=sqlite3.connect('clips.db'); print(*db.execute("SELECT triggered_at,score,reason,trigger_words FROM clips WHERE status='dry_run' ORDER BY id DESC LIMIT 20").fetchall(),sep='\n')"`.
5. Compare the timestamps with Sketch's VOD to evaluate missed moments and false positives. Use the results to change thresholds.
6. When you deliberately want real clips, change `DRY_RUN=false` and restart the process. Configure Discord webhooks privately then.

**Important:** The current dashboard primarily lists real clips, so the terminal/database are the authoritative dry-run results. You cannot run this Python service within Discord or a standalone iPhone browser. The dry run needs a computer or hosted server running while the stream is live. `DRY_RUN=true` disables clip requests and Discord notifications, but it still connects to Twitch with your account.

---

# Clip Hunter v6 — slow-chat detection, grouping, reliability, performance

A **prototype** built on v4. Not connected to your Twitch or Discord account, and not yet live-tested. Designed for a regular Twitch viewer account if the broadcaster's clip settings permit clipping.

## What changed

1. **Slow-chat scoring**: 2x 10-second activity vs rolling 5-minute baseline, minimum 4 usable messages and 3 distinct users (not 15/7). A unique-keyword trigger needs 4 distinct users within 15 seconds, including at least 2 meaningful (non-generic) reactions unless a chat spike is also happening. Heavy repetition is limited to 2 messages/user/10 sec, duplicate text by one person ignored for 10 sec, numeric-only text excluded entirely. Scores are approximate heuristic priorities from 0–100, not actual popularity predictions.
2. **Keyword families**: `detection.py` recognizes laughter, shock, disbelief, gaming reactions, chat slang, and repeated trailing letters (e.g., `lmaoooo`, `bruhhhh`, `wtffff`). Common filler (`why`, `what`, `w`, `l`, `lol`) is weak. Built-in phrase dictionary plus configurable `KEYWORDS` in `.env`. Distinct users, not keyword appearances, determine qualification.
3. **Group sustained reactions**: all clips in the same active burst get a shared highlight ID. A 30-second cooldown applies between events, but sustained signals permit overlapping clip requests roughly every 20 seconds. Event expires after 12s without qualifying detection, including when chat stops. Changes are saved to SQLite.
4. **Discord three-webhook integration**: `DISCORD_TOP_WEBHOOK_URL` for one editable high-priority highlight post (subsequent clips edit it), `DISCORD_ALL_WEBHOOK_URL` for each ready clip, `DISCORD_REPORT_WEBHOOK_URL` for daily reports. Default high priority threshold 85. Webhook messages are not verified until actual deployment; protect each URL.
5. **Reliability groundwork**: reconnect WebSocket after loss, refresh expired OAuth, poll live state, verify asynchronously created clips, record failures and events, and auto-start with provided systemd service. A scheduled job that dies still requires systemd or similar process supervision. Network, Twitch, and Discord errors require real-world testing.
6. **Post performance tracking**: the dashboard now allows manually marking a clip posted and recording platform, published link, views, and earnings. Tracking is manual (no TikTok/Shorts/Reels APIs connected). Dashboard stats API exposes totals. Also provides `/api/activity` for diagnostic logs.

## Setup when back on a personal computer

1. Python 3.11+ installed. Extract the ZIP and use `python -m pip install -r requirements.txt`.
2. Copy `.env.example` to `.env`. Set `TWITCH_CLIENT_ID`, `TWITCH_CLIENT_SECRET`, `TWITCH_CHANNEL`, `DASHBOARD_PASSWORD` and three Discord webhook URLs.
3. Run `python auth.py` and authorize your Twitch viewer account with the requested scopes.
4. Open separate terminals: `python bot.py` and `python dashboard.py`.
5. Open `http://127.0.0.1:8080` locally; browse clips, filter, mark reviewed, and track performance.
6. Run test suite before live use: `python -m unittest test_detection -v`.
7. VPS: Deploy on Ubuntu with systemd for bot and Gunicorn/Caddy HTTPS for dashboard, or use Tailscale for private mobile access. Never expose the development Flask server or use Basic Auth without HTTPS.

## Important limitations

- Twitch's **Create Clip** API offers live capture over a recent window but does NOT expose exact start/end timestamps for normal viewer accounts. The 45s-before/15s-after target uses a 15-second wait followed by a 60-second live clip request; this is approximate, and timing needs measurement on a real stream. The `edit_url` returned by Twitch can be used to refine the 60-second selection manually while valid.
- Twitch Create Clip is asynchronous; a request may fail due to streamer settings, token permissions, network conditions, or rate limits. If no clip appears by approximately 60 seconds, it's stored as unconfirmed; do not assume Twitch published it.
- Clips created as 60 seconds may require validation of actual clip boundaries. Direct VOD clipping at exact offsets requires broadcaster or editor permissions.
- Top Discord message editing groups links but a message caps at 2000 characters; only the most recent 12 links are included for extremely long bursts. All links are kept in SQLite and sent individually to `#all-clips` if its webhook is provided.
- Scores are heuristics. Start with the slow-chat defaults and review 3–5 streams before further threshold changes.
- Dashboard settings are **not** dynamically applied to the bot; change `.env` then restart the bot. Twitch account, webhook URLs, OAuth tokens and dashboard password belong ONLY in local/server configuration; do not send to chat.
- Any `DASHBOARD_PASSWORD` and .env configuration is sensitive. Use HTTPS, secure server access, and ideally a private network. Updates are not a substitute for production monitoring.

## Keyword families (v6)

`detection.py` now uses weighted keyword families with multiple aliases rather than requiring a long flat keyword list. Families include `clip_request`, `disbelief`, `shock`, `laughter`, `hype`, `fail_drama`, `football_madden`, `twitch_emotes`, `general_reactions`, `sketch_context`, and `common_chat`. Repeated-letter patterns normalize examples such as `wtffff`, `bruhhhhh`, `lmaoooo`, `clippp`, `noooo way` and `lololol`; matches require whole words or phrases to avoid substring false positives. A single user still counts once per keyword window.

`KEYWORDS` in `.env` should now contain **only your extra custom phrases**, not the built-in aliases; default channel is `thesketchreal`. The score is a heuristic and channel-specific keywords may need tuning after live testing. No user webhook credentials are bundled.
