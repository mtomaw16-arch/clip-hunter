"""Slow-chat highlight detection with configurable keyword families.

Every distinct viewer contributes at most once to the 15-second keyword window.
Matches use complete tokens or complete phrases; substrings in unrelated words
must not trigger clips. Categories/weights are deliberately conservative.
"""
from collections import deque, Counter
from dataclasses import dataclass
import re

# Strength 3 = high signal, 2 = medium, 1 = common chat filler.
# Aliases collapse to a canonical family instead of storing every spelling.
KEYWORD_FAMILIES = {
    'clip_request': (3, ('clip', 'clip that', 'clip it', 'clip this', 'someone clip',
        'somebody clip', 'clip that shit', 'clip that bro', 'clippp', 'save that',
        'run it back', 'run that back', 'run it again', 'replay that', 'clip of the year',
        'someone get that', 'this needs a clip', 'get clipped', 'clip him')),
    'disbelief': (3, ('no way', 'no shot', 'ain t no way', 'aint no way',
        'there is no way', 'no fucking way', 'ain t no fucking way',
        'hell nah', 'oh hell nah', 'nah no way', 'bro what', 'what just happened',
        'are you serious', 'you re joking', 'youre joking', 'did that happen')),
    'shock': (3, ('wtf', 'wtff', 'wtaf', 'omfg', 'holy shit', 'what the fuck',
        'oh my god', 'oh my fucking god', 'holy', 'unbelievable', 'unreal',
        'jumpscare', 'shocked', 'whattt', 'yikes', 'what is happening')),
    'laughter': (3, ('lmao', 'lmfao', 'rofl', 'hahaha', 'hahahaha', 'kekw',
        'kewk', 'omegalul', 'lulw', 'pepelaugh', 'im dead', 'i m dead',
        'im crying', 'i m crying', 'im weak', 'i m weak', 'dying',
        'crying', 'screaming', 'hilarious', 'deadass', 'i cant breathe')),
    'hype': (3, ('insane', 'clutch', 'goated', 'legendary', 'nuts',
        'crazy', 'wild', 'banger', 'peak', 'cinema', 'lets go', 'let s go',
        'lfg', 'sheesh', 'sheeeesh', 'yooo', 'pog', 'poggers',
        'no fucking way bro', 'that was insane')),
    'fail_drama': (2, ('cooked', 'choked', 'throwing', 'exposed', 'caught',
        'embarrassing', 'disaster', 'rigged', 'scripted', 'washed',
        'sold the bag', 'sold', 'ripbozo', 'rip', 'fumbled', 'fumble',
        'what a throw', 'he is cooked', 'she is cooked', 'thats crazy')),
    'football_madden': (2, ('td', 'touchdown', 'user pick', 'interception',
        'picked off', 'picked', 'sacked', 'pick six', 'pick 6',
        'mossed', 'dot', 'dime', 'ankles', 'pick', 'busted',
        'sack', 'tuddie', 'tuddy', 'ggs')),
    'twitch_emotes': (2, ('lul', 'pepega', 'monkas', 'monkaw', 'sadge',
        'feelsbadman', 'ezclap', 'omegalul', 'kekw', 'kewk')),
    'general_reactions': (2, ('omg', 'bruh', 'bruhhh', 'broooo',
        'whoa', 'woah', 'wow', 'ayo', 'sheesh', 'nice', 'huge',
        'clean', 'nasty', 'goat', 'oof', 'nocap', 'based', 'yapping')),
    'sketch_context': (1, ('whats up brother', 'what s up brother',
        'tuesday', 'special teams', 'case closed', 'god bless', 'brother')),
    'common_chat': (1, ('lol', 'haha', 'hehe', 'what', 'why', 'bro',
        'w', 'l', 'gg', 'nice', 'oh', 'wait', 'again', 'true',
        'nah', 'huh', 'f', 'ez', 'chat', 'yes', 'no')),
}

NUMBER_ONLY = re.compile(r'^[\W\d_]+$', re.UNICODE)
WORD = re.compile(r'[a-z]+', re.I)

# These are *exact* token families. Repeated endings/alternate ha and lol
# laughter are supported without substring matching inside normal words.
FAMILY_PATTERNS = (
    (re.compile(r'wtf+'), 'wtf'),
    (re.compile(r'lmao+'), 'lmao'),
    (re.compile(r'lmfao+'), 'lmfao'),
    (re.compile(r'lo+l+'), 'lol'),
    (re.compile(r'lo(?:lo)+l'), 'lol'),
    (re.compile(r'(?:ha){2,}h*'), 'hahaha'),
    (re.compile(r'bruh+'), 'bruh'),
    (re.compile(r'bro+'), 'bro'),
    (re.compile(r'omg+'), 'omg'),
    (re.compile(r'omfg+'), 'omfg'),
    (re.compile(r'no+'), 'no'),
    (re.compile(r'yo+'), 'yooo'),
    (re.compile(r'she+sh+'), 'sheesh'),
    (re.compile(r'ke+w+k+'), 'kewk'),
    (re.compile(r'kekw+'), 'kekw'),
    (re.compile(r'clip+'), 'clip'),
    (re.compile(r'crazy+'), 'crazy'),
    (re.compile(r'why+'), 'why'),
)

def simplify(word):
    """Canonicalize common chat exaggerations only at complete-token level."""
    w=word.casefold()
    for pattern,canonical in FAMILY_PATTERNS:
        if pattern.fullmatch(w): return canonical
    # Narrow extra-long ending compression only: e.g. 'insaneee' -> 'insanee'.
    return w

def normalize(message):
    # Apostrophes and punctuation become separators; numerals never match tags.
    return [simplify(w) for w in WORD.findall(re.sub(r'\d+', ' ', message.casefold()))]

def family_index(extra_keywords=()):
    """Family membership is configurable with weighted built-ins and user aliases."""
    index={}
    for family,(weight,aliases) in KEYWORD_FAMILIES.items():
        for alias in aliases:
            key=tuple(normalize(alias))
            if key and (key not in index or weight>index[key][0]):
                index[key]=(weight,family)
    for alias in extra_keywords:
        key=tuple(normalize(str(alias)))
        if not key:continue
        # User keywords add custom family matches; the most specific built-in
        # weight takes precedence so 'why' does not become a strong signal.
        weight=index.get(key,(2,''))[0]
        if key not in index:index[key]=(weight,'custom')
    return index

BUILTIN_INDEX=family_index()

def classify_message(message, extra_keywords=()):
    """Return (strongest weight, canonical family names, usable-chat flag)."""
    raw=message.strip()
    if not raw or NUMBER_ONLY.fullmatch(raw):return 0, [], False
    words=normalize(raw)
    if not words:return 0, [], False
    index=BUILTIN_INDEX if not extra_keywords else family_index(extra_keywords)
    strength=0;matches=[]
    # Sentence tokens compared against keyword aliases with word boundaries.
    for alias,(weight,family) in index.items():
        n=len(alias)
        if any(tuple(words[i:i+n])==alias for i in range(len(words)-n+1)):
            strength=max(strength,weight)
            matches.append(family)
    return strength,list(dict.fromkeys(matches)),True

@dataclass
class Signal:
    score:int
    kind:str
    ratio:float
    keyword_users:int
    unique_users:int
    matches:list

class Detector:
    def __init__(self,spike_multiplier=2,keyword_users=4,extra_keywords=(),min_spike_messages=4,min_unique_spike=3):
        self.events=deque() # (timestamp, chatter, strength, keywords)
        self.spike_multiplier=spike_multiplier
        self.keyword_users=keyword_users
        self.extra_keywords=extra_keywords
        self.min_spike_messages=min_spike_messages
        self.min_unique_spike=min_unique_spike
        self.last_by_user={}

    def add(self,now,user,message):
        strength,matches,usable=classify_message(message,self.extra_keywords)
        if not usable:return None
        # Ignore identical repeats by same user in a short window.
        norm=' '.join(WORD.findall(re.sub(r'\d+',' ',message.casefold())))
        prev=self.last_by_user.get(user)
        if prev and prev[0]==norm and now-prev[1]<10:return None
        self.last_by_user[user]=(norm,now)
        self.events.append((now,user,strength,matches))
        while self.events and self.events[0][0]<now-310:self.events.popleft()
        for uid,(_,t) in list(self.last_by_user.items()):
            if now-t>30:del self.last_by_user[uid]
        return self.evaluate(now)

    def evaluate(self,now):
        current=[e for e in self.events if now-10<=e[0]<=now]
        baseline=[e for e in self.events if now-310<=e[0]<now-10]
        # Count at most two messages per user in each ten-second bucket.
        def weighted_count(events):
            seen=Counter();n=0
            for t,uid,_,_ in events:
                key=(uid,int(t//10))
                seen[key]+=1
                if seen[key]<=2:n+=1
            return n
        curr=weighted_count(current)
        base=weighted_count(baseline)/30
        # For quiet chat: 2 messages/10sec baseline and 5 current = 2.5x.
        # A minimum baseline prevents 1-to-2 chatter becoming an infinite spike.
        ratio=curr/max(base,1.0)
        uniq=len({e[1] for e in current})
        spike=curr>=self.min_spike_messages and uniq>=self.min_unique_spike and ratio>=self.spike_multiplier
        # Keyword chatter: each chatter contributes once, no matter messages sent.
        kw_events=[e for e in self.events if e[0]>=now-15 and e[2]>0]
        per_user={}
        for _,uid,strength,matches in kw_events:
            if strength>per_user.get(uid,(0,[]))[0]:per_user[uid]=(strength,matches)
        n=len(per_user)
        strong=sum(1 for w,_ in per_user.values() if w>=2)
        very_strong=sum(1 for w,_ in per_user.values() if w>=3)
        meaningful=n>=self.keyword_users and (strong>=2 or (spike and strong>=1))
        if not spike and not meaningful:return None
        # avoid treating four generic 'why' messages as a high priority clip.
        score=25+min(28,round(max(0,ratio-1)*9)) if spike else 20
        score+=min(26,strong*6)+min(12,very_strong*3)
        if meaningful:score+=14
        if spike and meaningful:score+=12
        score=min(100,max(1,score))
        matches=Counter(k for _,ks in per_user.values() for k in ks)
        return Signal(score,'spike+keywords' if spike and meaningful else 'chat_spike' if spike else 'keywords',round(ratio,2),n,uniq,[k for k,_ in matches.most_common(5)])
