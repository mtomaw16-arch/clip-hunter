import unittest
from detection import Detector,classify_message

class TestDetection(unittest.TestCase):
    def test_numeric_only_ignored(self):
        for m in ['777777','1 2 3','69!!!','1000000','🔥777🔥']:
            self.assertFalse(classify_message(m)[2],m)
    def test_numeric_mixed_keeps_words(self):
        self.assertTrue(classify_message('123456 LMAOOO')[2])
        self.assertGreaterEqual(classify_message('123456 LMAOOO')[0],2)
    def test_variations(self):
        for m in ['wtffff','lolllll','lmaoooo','bruhhhh','no way','CLIP THAT','kewk','omgggg']:
            self.assertGreater(classify_message(m)[0],0,m)
    def test_low_chat_spike(self):
        d=Detector()
        for t in range(0,300,10):d.add(t,'normal'+str(t),'regular discussion')
        signals=[]
        for i in range(5):signals.append(d.add(310+i,'p'+str(i),'regular discussion'))
        self.assertTrue(any(x and x.kind=='chat_spike' for x in signals))
    def test_four_unique_keyword_users(self):
        d=Detector()
        result=None
        for i,msg in enumerate(['wtffff','no way','lmaoooo','clip that']):result=d.add(10+i,'p'+str(i),msg)
        self.assertIsNotNone(result)
        self.assertEqual(result.keyword_users,4)
    def test_one_person_spam_does_not_trigger(self):
        d=Detector()
        for i in range(20):self.assertIsNone(d.add(10+i*.25,'p1','lolllll'))
    def test_weak_only_does_not_trigger_keywords(self):
        d=Detector()
        for i in range(4):
            result=d.add(10+i,'p'+str(i),'why')
            if result:self.assertEqual(result.kind,'chat_spike')

    def test_keyword_family_variants(self):
        pairs = [('LOLolol','common_chat'),('lmaooooooo','laughter'),
                 ('bruhhhhh','general_reactions'),('WTFFFFFF','shock'),
                 ('CLIPPPP','clip_request'),('nooooo way','disbelief'),
                 ('sheeeesh','hype'),('touchdown','football_madden'),
                 ('whats up brother','sketch_context')]
        for msg,expected in pairs:
            strength,families,usable=classify_message(msg)
            self.assertTrue(usable,msg)
            self.assertIn(expected,families,msg)
    def test_no_substring_false_matches(self):
        for msg in ['normal conversation', 'clipping software', 'brolly', 'photography']:
            weight,families,usable=classify_message(msg)
            self.assertTrue(usable)
            self.assertEqual(weight,0,msg)
    def test_custom_keyword_phrase(self):
        self.assertIn('custom',classify_message('chat is this real',('chat is this real',))[1])
    def test_number_spam_excluded_from_baseline(self):
        d=Detector()
        for i in range(20):
            self.assertIsNone(d.add(i,'num'+str(i),'777777'))
        self.assertEqual(len(d.events),0)

if __name__=='__main__':unittest.main()
