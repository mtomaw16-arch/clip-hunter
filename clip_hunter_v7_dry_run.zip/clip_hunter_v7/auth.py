"""Run locally once to authorize your own Twitch account; copies tokens.json securely to the VPS."""
import json, os, secrets, urllib.parse, webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import requests
from dotenv import load_dotenv

load_dotenv()
CLIENT = os.environ['TWITCH_CLIENT_ID']
SECRET = os.environ['TWITCH_CLIENT_SECRET']
REDIRECT = os.getenv('TWITCH_REDIRECT_URI', 'http://localhost:8765/callback')
SCOPES = 'user:read:chat clips:edit'
state = secrets.token_urlsafe(24)
parsed = urllib.parse.urlparse(REDIRECT)
assert parsed.hostname in ('localhost', '127.0.0.1'), 'For initial setup, use a localhost redirect URI.'
assert parsed.path == '/callback', 'Redirect URI path must be /callback'

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        if query.get('state', [''])[0] != state or 'code' not in query:
            self.send_response(400); self.end_headers(); self.wfile.write(b'Invalid OAuth callback'); return
        r = requests.post('https://id.twitch.tv/oauth2/token', data={
            'client_id': CLIENT, 'client_secret': SECRET, 'code': query['code'][0],
            'grant_type': 'authorization_code', 'redirect_uri': REDIRECT
        }, timeout=20)
        r.raise_for_status()
        token_path = Path('tokens.json')
        token_path.write_text(json.dumps(r.json(), indent=2))
        try: token_path.chmod(0o600)
        except OSError: pass
        self.send_response(200); self.end_headers()
        self.wfile.write(b'Authorized. You may close this tab.')
        print('Saved tokens.json. Keep this file SECRET.')

url = 'https://id.twitch.tv/oauth2/authorize?' + urllib.parse.urlencode({
    'response_type': 'code', 'client_id': CLIENT, 'redirect_uri': REDIRECT,
    'scope': SCOPES, 'state': state
})
print('Open this URL to log into your CLIPPER account:\n' + url)
webbrowser.open(url)
HTTPServer((parsed.hostname, parsed.port or 80), Handler).handle_request()
