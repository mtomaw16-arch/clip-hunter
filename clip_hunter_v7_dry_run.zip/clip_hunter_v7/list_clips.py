import sqlite3
from pathlib import Path
if not Path('clips.db').exists():
    print('No clips.db yet. Run bot.py first.')
else:
    db=sqlite3.connect('clips.db')
    for row in db.execute('SELECT ts,score,reason,status,url FROM clips ORDER BY id DESC LIMIT 100'):
        print(' | '.join(str(x or '') for x in row))
