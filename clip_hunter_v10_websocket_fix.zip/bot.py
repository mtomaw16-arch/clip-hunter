"""Twitch live-chat-triggered clip bot. No channel editor permission required."""
import asyncio, collections, json, logging, os, re, sqlite3, time
from pathlib import Path
from datetime import datetime, timezone, timedelta
from store import connect
from detection import Detector

import aiohttp
import websockets
from dotenv import load_dotenv

load_dotenv()
CLIENT_ID = os.environ['TWITCH_CLIENT_ID']
CLIENT_SECRET = os.environ['TWITCH_CLIENT_SECRET']
CHANNEL = os.environ['TWITCH_CHANNEL'].lower().lstrip('@')
DISCORD = os.getenv('DISCORD_TOP_WEBHOOK_URL', os.getenv('DISCORD_WEBHOOK_URL', ''))
DISCORD_ALL = os.getenv('DISCORD_ALL_WEBHOOK_URL', '')
DISCORD_REPORT = os.getenv('DISCORD_REPORT_WEBHOOK_URL', DISCORD)
SPIKE_MULT = float(os.getenv('SPIKE_MULTIPLIER', '2'))
SPIKE_MIN = int(os.getenv('SPIKE_MIN_MESSAGES', '4'))
SPIKE_USERS = int(os.getenv('SPIKE_MIN_UNIQUE_USERS', '3'))
KEYWORD_USERS = int(os.getenv('KEYWORD_MIN_UNIQUE_USERS', '4'))
DURATION = max(5, min(60, float(os.getenv('CLIP_DURATION', '60'))))
DRY_RUN = os.getenv('DRY_RUN', 'true').strip().lower() in ('true', '1', 'yes', 'on')
POST_TRIGGER_SECONDS = max(0, float(os.getenv('POST_TRIGGER_SECONDS', '15')))  # approximate 45-before / 15-after targeting
COOLDOWN = int(os.getenv('COOLDOWN_SECONDS', '30'))
CONTINUOUS_INTERVAL = max(15, int(os.getenv('CONTINUOUS_CLIP_INTERVAL_SECONDS', '20')))
EVENT_GRACE = max(5, int(os.getenv('EVENT_GRACE_SECONDS', '12')))
KEYWORDS = [x.strip().casefold() for x in os.getenv('KEYWORDS', 'clip that,wtf,no way').split(',') if x.strip()]
TOKENS = Path('tokens.json')
log = logging.getLogger('clip_hunter')

class Bot:
    def __init__(self):
        self.tokens = json.loads(TOKENS.read_text())
        self.http = None
        self.bot_id = None
        self.channel_id = None
        self.live = False
        self.detector = Detector(SPIKE_MULT, KEYWORD_USERS, KEYWORDS, SPIKE_MIN, SPIKE_USERS)
        self.last_trigger = 0
        self.last_signal = 0
        self.active_highlight = False
        self.last_clip = None
        self.db = connect()
        self.group_id = int(self.db.execute('SELECT COALESCE(MAX(id),0) FROM highlights').fetchone()[0])
        self.pending_tasks = set()
        self.last_clip_by_group = {}
        self.discord_lock = asyncio.Lock()
        self.session_id = None
        self._restore_session()

    def _restore_session(self):
        row = self.db.execute("SELECT id FROM stream_sessions WHERE status='live' ORDER BY id DESC LIMIT 1").fetchone()
        self.session_id = row['id'] if row else None

    def mark_online(self):
        # Same session survives process restarts, EventSub reconnects and duplicate events.
        if self.session_id is not None:
            return
        now = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
        cur = self.db.execute('INSERT INTO stream_sessions(started_at) VALUES (?)', (now,))
        self.session_id = cur.lastrowid
        self.db.commit()
        self.log_event('stream_started', f'Session #{self.session_id}')

    def mark_offline(self):
        if self.session_id is None:
            return
        # Five minutes after OFFLINE detection; API polling may detect late.
        now = datetime.now(timezone.utc)
        self.db.execute("""UPDATE stream_sessions SET status='ended',ended_at=?,report_due_at=?
            WHERE id=? AND status='live'""", (now.strftime('%Y-%m-%d %H:%M:%S'),
            (now+timedelta(minutes=5)).strftime('%Y-%m-%d %H:%M:%S'),self.session_id))
        self.db.commit()
        self.log_event('stream_ended', f'Session #{self.session_id}: report scheduled in 5 minutes')
        self.session_id = None

    def clip_embed(self, group_id,score,reason,ratio,keyword_users,words,url,triggered_at,clip_title):
        if reason=='spike+keywords': explanation='Chat activity spike and multiple viewers reacting'
        elif reason=='chat_spike': explanation='Chat activity spiked above the rolling baseline'
        else: explanation='Multiple unique viewers reacted with tracked keywords'
        timestamp=datetime.fromtimestamp(triggered_at,timezone.utc).strftime('%H:%M:%S UTC')
        return {'title':f'🎬 {clip_title} · {score}/100',
                'description':explanation+'\n'+url,
                'color':0x7950D9,
                'fields':[{'name':'Highlight','value':f'#{group_id}','inline':True},
                          {'name':'Trigger type','value':reason,'inline':True},
                          {'name':'Chat activity','value':f'{ratio:.1f}× baseline','inline':True},
                          {'name':'Keyword viewers','value':str(keyword_users),'inline':True},
                          {'name':'Matched keyword families','value':', '.join(words[:8]) or 'No keyword matches','inline':False},
                          {'name':'Detected at','value':timestamp,'inline':True},
                          {'name':'Clip target','value':'60s · approximately 45s before / 15s after','inline':False}],
                'url':url}

    def headers(self):
        return {'Client-Id': CLIENT_ID, 'Authorization': 'Bearer ' + self.tokens['access_token']}

    async def refresh(self):
        async with self.http.post('https://id.twitch.tv/oauth2/token', data={
            'grant_type': 'refresh_token', 'refresh_token': self.tokens['refresh_token'],
            'client_id': CLIENT_ID, 'client_secret': CLIENT_SECRET}) as resp:
            response = await resp.text()
            if resp.status != 200: raise RuntimeError(f'OAuth refresh failed ({resp.status}): {response}')
            self.tokens.update(json.loads(response))
            TOKENS.write_text(json.dumps(self.tokens, indent=2))
            try: TOKENS.chmod(0o600)
            except OSError: pass

    async def api(self, method, path, *, params=None, payload=None):
        url = 'https://api.twitch.tv/helix/' + path
        for attempt in range(2):
            async with self.http.request(method, url, params=params, json=payload, headers=self.headers()) as r:
                content = await r.text()
                if r.status == 401 and attempt == 0:
                    await self.refresh(); continue
                if r.status >= 400: raise RuntimeError(f'{method} {path}: HTTP {r.status}: {content[:400]}')
                return json.loads(content) if content else {}

    async def setup(self):
        # Refresh proactively on startup; this also tests token health.
        await self.refresh()
        ids = await self.api('GET', 'users', params=[('login', CHANNEL)])
        if not ids['data']: raise RuntimeError('Channel not found: ' + CHANNEL)
        self.channel_id = ids['data'][0]['id']
        me = await self.api('GET', 'users')
        self.bot_id = me['data'][0]['id']
        await self.check_live()
        log.info('Monitoring %s as user %s. Live=%s. DRY_RUN=%s', CHANNEL, self.bot_id, self.live, DRY_RUN)

    async def check_live(self):
        result = await self.api('GET', 'streams', params={'user_id': self.channel_id})
        was_live = self.live
        self.live = bool(result['data'])
        if self.live:
            self.mark_online()
        else:
            self.mark_offline()
            self.detector.events.clear()
            self.active_highlight = False
            self.last_signal = 0
        if was_live != self.live: log.info('Stream state changed: %s', 'LIVE' if self.live else 'OFFLINE')

    async def subscribe(self, session_id):
        subscriptions = [
            ('stream.online', {'broadcaster_user_id': self.channel_id}),
            ('stream.offline', {'broadcaster_user_id': self.channel_id}),
            ('channel.chat.message', {'broadcaster_user_id': self.channel_id, 'user_id': self.bot_id}),
        ]
        for typ, condition in subscriptions:
            await self.api('POST', 'eventsub/subscriptions', payload={
                'type': typ, 'version': '1', 'condition': condition,
                'transport': {'method': 'websocket', 'session_id': session_id}
            })
        log.info('Subscribed to stream and chat events')

    def record(self, reason, score, clip_id, url, status, edit_url='', thumbnail='', group_id=None, ratio=0, keyword_users=0, discord_status='pending', trigger_words='', triggered_at='', clip_title='', clip_number=None, stream_session_id=None):
        self.db.execute('''INSERT INTO clips(reason, score, clip_id, url, status, edit_url, thumbnail_url, group_id, spike_ratio, keyword_users, discord_status, trigger_words, triggered_at, clip_title, clip_number, stream_session_id)
                           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                        (reason, score, clip_id, url, status, edit_url, thumbnail, group_id, ratio, keyword_users, discord_status, trigger_words, triggered_at, clip_title, clip_number, stream_session_id))
        self.db.commit()

    def next_clip_title(self):
        # Reserve each number in SQLite before the Twitch request. Numbers reset
        # at the start of a new stream and survive process restarts. Failed clip
        # requests may leave gaps; we never reuse a potentially published title.
        if self.session_id is None:
            raise RuntimeError('Cannot number a clip without an active stream session')
        self.db.execute('INSERT OR IGNORE INTO clip_sequences(session_id,last_number) VALUES (?,0)', (self.session_id,))
        self.db.execute('UPDATE clip_sequences SET last_number=last_number+1 WHERE session_id=?', (self.session_id,))
        number = self.db.execute('SELECT last_number FROM clip_sequences WHERE session_id=?', (self.session_id,)).fetchone()[0]
        self.db.commit()
        return number, f'Sketch - {number:03d}', self.session_id

    def log_event(self, kind, desc):
        self.db.execute('INSERT INTO event_log(event_type,description) VALUES (?,?)',(kind,desc))
        self.db.commit()

    async def discord_request(self, webhook, payload, message_id=None):
        if not webhook:return None
        url=webhook.rstrip('/')
        if message_id:
            url += '/messages/' + str(message_id)
            method='PATCH'
        else:
            url += ('&' if '?' in url else '?') + 'wait=true'
            method='POST'
        try:
            async with self.http.request(method,url,json=payload,timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status not in (200,201,204):
                    log.warning('Discord %s response HTTP %s',method,resp.status)
                    return None
                data=await resp.json(content_type=None) if resp.status!=204 else {}
                return data.get('id') or message_id or 'sent'
        except Exception as exc:
            log.warning('Discord notification failed: %s',exc)
            return None

    async def send_discord(self, content, webhook=None):
        return 'sent' if await self.discord_request(webhook or DISCORD, {'content':content,'allowed_mentions':{'parse':[]}}) else 'failed'

    async def notify_clip(self, group_id, score, reason, ratio, keyword_users, words, url, triggered_at, clip_title):
        # Every ready clip goes to #all-clips. High-priority event gets ONE
        # editable top-clips message; later clips amend it without new pings.
        if DISCORD_ALL:
            await self.discord_request(DISCORD_ALL,{'embeds':[self.clip_embed(group_id,score,reason,ratio,keyword_users,words,url,triggered_at,clip_title)], 'allowed_mentions':{'parse':[]}})
        if not DISCORD:return 'disabled'
        best=self.db.execute('SELECT best_score FROM highlights WHERE id=?',(group_id,)).fetchone()
        best_score=max(score,best['best_score'] if best else 0)
        if best_score<int(os.getenv('DISCORD_MIN_SCORE','85')):return 'below_threshold'
        row=self.db.execute('SELECT discord_message_id FROM highlights WHERE id=?',(group_id,)).fetchone()
        message_id=row['discord_message_id'] if row else None
        rows=self.db.execute("""SELECT url,score,reason,spike_ratio,keyword_users,trigger_words,triggered_at,clip_title
            FROM clips WHERE group_id=? AND status='ready' ORDER BY id""",(group_id,)).fetchall()
        # Compact per-clip explanations, not just bare URLs.
        lines=[]
        for i,r in enumerate(rows[-8:],1):
            words_label=r['trigger_words'] or 'activity'
            when=(r['triggered_at'] or '').replace('T',' ')[:19]
            lines.append(f'{i}. **{r["clip_title"] or "Clip"}** · {r["score"]}/100 · {r["reason"]} · {r["spike_ratio"] or 0:.1f}× · '
                         f'{r["keyword_users"] or 0} keyword users · {words_label} · {when} UTC\n{r["url"]}')
        if url not in [r['url'] for r in rows]:
            lines.append(url)
        content=(f'🔥 **{CHANNEL} · Highlight #{group_id}** · Best score {best_score}/100\n'
                 + '\n'.join(lines))
        if len(content)>1900: content=content[:1900]
        result=await self.discord_request(DISCORD,{'content':content,'allowed_mentions':{'parse':[]}},message_id)
        if result and result!='sent' and not message_id:
            self.db.execute('UPDATE highlights SET discord_message_id=? WHERE id=?',(str(result),group_id));self.db.commit()
        return 'sent' if result else 'failed'

    async def report_completed_streams(self):
        # The due time is stored persistently so restarts cannot lose a report.
        if not DISCORD_REPORT:
            return
        now=datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
        sessions=self.db.execute("""SELECT * FROM stream_sessions WHERE status='ended'
            AND report_due_at<=? AND report_sent_at IS NULL ORDER BY id""", (now,)).fetchall()
        for session in sessions:
            # A short grace period after stream end includes any late clip verification.
            rows=self.db.execute("""SELECT url,score,reason,spike_ratio,keyword_users,trigger_words,triggered_at,clip_title,
                group_id FROM clips WHERE status='ready' AND ts >= ? AND ts <= ?
                ORDER BY score DESC, id DESC""", (session['started_at'],
                (datetime.strptime(session['ended_at'],'%Y-%m-%d %H:%M:%S')+timedelta(minutes=2)).strftime('%Y-%m-%d %H:%M:%S'))).fetchall()
            high=sum(1 for r in rows if r['score']>=int(os.getenv('DISCORD_MIN_SCORE','85')))
            groups=len({r['group_id'] for r in rows if r['group_id'] is not None})
            msg=(f'📊 **{CHANNEL} · Stream recap**\n'
                 f'**Stream:** {session["started_at"]} to {session["ended_at"]} UTC\n'
                 f'**Clips:** {len(rows)} | **High priority:** {high} | **Highlight groups:** {groups}\n')
            if not rows:
                msg+='No ready clips were created in this session.'
            else:
                msg+='**Top clips:**\n'
                for i,r in enumerate(rows[:5],1):
                    families=r['trigger_words'] or 'activity'
                    msg+=f'{i}. **{r["clip_title"] or "Clip"}** · {r["score"]}/100 · {r["reason"]} · {families}\n{r["url"]}\n'
            result=await self.discord_request(DISCORD_REPORT,{'content':msg[:1950], 'allowed_mentions':{'parse':[]}})
            if result:
                self.db.execute('UPDATE stream_sessions SET report_sent_at=? WHERE id=?',(now,session['id']))
                self.db.commit()
                log.info('Discord stream recap sent for session %s',session['id'])
            else:
                log.warning('Stream recap failed; will retry later for session %s',session['id'])

    async def session_report_loop(self):
        while True:
            await asyncio.sleep(10)
            try:
                await self.report_completed_streams()
            except Exception:
                log.exception('Stream report error; retry scheduled')


    async def delayed_clip(self, reason, score, ratio, word_count, triggered_at, group_id, words):
        """Wait until after the chat spike before requesting a backward-looking live clip.

        Twitch chooses the final placement. A viewer token cannot enforce exact offsets.
        Use an absolute time so delayed scheduling doesn't accumulate additional drift.
        """
        await asyncio.sleep(max(0, triggered_at + POST_TRIGGER_SECONDS - time.time()))
        if not self.live:
            log.info('Skipping scheduled clip: stream went offline')
            return
        log.info('Requesting clip %.1fs after detected reaction', time.time() - triggered_at)
        if DRY_RUN:
            self.record(reason, score, '', '', 'dry_run', group_id=group_id,
                        ratio=ratio, keyword_users=word_count, discord_status='disabled',
                        trigger_words=','.join(words),
                        triggered_at=datetime.fromtimestamp(triggered_at, timezone.utc).isoformat())
            self.log_event('dry_run_clip', f'Would clip: highlight #{group_id}, score {score}, {reason}, words={words}')
            log.info('DRY RUN: Would create clip for highlight #%s (score=%s, ratio=%.1f, keywords=%s)',
                     group_id, score, ratio, words)
            return
        await self.clip(reason, score, ratio, word_count, group_id, words, triggered_at)

    async def clip(self, reason, score, ratio, word_count, group_id, words, triggered_at):
        try:
            number, title, stream_session_id = self.next_clip_title()
            response = await self.api('POST', 'clips', params={
                'broadcaster_id': self.channel_id, 'duration': DURATION, 'title': title
            })
            data = response['data'][0]
            clip_id = data['id']
            edit_url = data.get('edit_url', '')
            log.info('Clip requested: %s (%s, score %s)', clip_id, reason, score)
            for _ in range(12):
                await asyncio.sleep(5)
                result = await self.api('GET', 'clips', params={'id': clip_id})
                if result.get('data'):
                    clip_data = result['data'][0]
                    url = clip_data['url']
                    thumbnail = clip_data.get('thumbnail_url','')
                    # Send only high-priority alerts, avoid clutter during sustained events.
                    self.record(reason, score, clip_id, url, 'ready', edit_url, thumbnail, group_id, ratio, word_count, 'pending', ','.join(words), datetime.fromtimestamp(triggered_at, timezone.utc).isoformat(), title, number, stream_session_id)
                    async with self.discord_lock:
                        sent = await self.notify_clip(group_id,score,reason,ratio,word_count,words,url,triggered_at,title)
                    self.db.execute('UPDATE clips SET discord_status=? WHERE clip_id=?',(sent,clip_id));self.db.commit()
                    log.info('Clip ready: %s', url)
                    return
            self.record(reason, score, clip_id, '', 'unconfirmed', edit_url, group_id=group_id, ratio=ratio, keyword_users=word_count, clip_title=title, clip_number=number, stream_session_id=stream_session_id)
            log.warning('Clip unconfirmed after 60s: %s', clip_id)
        except Exception as e:
            self.record(reason, score, '', '', 'failed', group_id=group_id, ratio=ratio, keyword_users=word_count, clip_title=locals().get('title',''), clip_number=locals().get('number'), stream_session_id=locals().get('stream_session_id'))
            log.error('Clip failed: %s', e)

    async def notification(self, packet):
        typ = packet['payload']['subscription']['type']
        event = packet['payload']['event']
        if typ == 'stream.online':
            self.live = True
            self.mark_online()
            self.detector.events.clear()
            self.active_highlight = False
            self.last_signal = 0
            log.info('Stream online')
        elif typ == 'stream.offline':
            self.live = False
            self.mark_offline()
            self.detector.events.clear()
            self.active_highlight = False
            self.last_signal = 0
            log.info('Stream offline')
        elif typ == 'channel.chat.message' and self.live:
            now=time.time()
            user=event.get('chatter_user_id') or event.get('chatter_user_login')
            text=event.get('message',{}).get('text','')
            detection=self.detector.add(now,user,text)
            # Signals expire even in quiet chat; ticks also end highlights.
            self.expire_highlight(now)
            if not detection:return
            self.last_signal=now
            continuing=self.active_highlight
            if not continuing:
                # Normal cooldown is applied between separate highlights.
                if now-self.last_trigger<COOLDOWN:return
                self.active_highlight=True
                self.group_id+=1
                self.db.execute('INSERT INTO highlights(id,best_score,last_signal) VALUES (?,?,?)',
                                (self.group_id,detection.score,now));self.db.commit()
                self.log_event('highlight_started',f'Group {self.group_id} · {detection.kind}')
            else:
                self.db.execute('UPDATE highlights SET best_score=MAX(best_score,?),last_signal=? WHERE id=?',
                                (detection.score,now,self.group_id));self.db.commit()
            interval=CONTINUOUS_INTERVAL if continuing else COOLDOWN
            if now-self.last_trigger<interval:return
            self.last_trigger=now
            self.log_event('trigger',f'Group {self.group_id}, score {detection.score}, {detection.kind}')
            task=asyncio.create_task(self.delayed_clip(detection.kind,detection.score,detection.ratio,
                                  detection.keyword_users,now,self.group_id,detection.matches))
            self.pending_tasks.add(task)
            task.add_done_callback(self.pending_tasks.discard)

    def expire_highlight(self, now):
        if self.active_highlight and now-self.last_signal>EVENT_GRACE:
            self.active_highlight=False
            self.db.execute("UPDATE highlights SET status='ended', ended_at=CURRENT_TIMESTAMP WHERE id=?",(self.group_id,));self.db.commit()
            self.log_event('highlight_ended',f'Group {self.group_id}')

    async def run_socket(self):
        """Listen for EventSub; keep the old socket open during Twitch reconnects."""
        origin = 'wss://eventsub.wss.twitch.tv/ws'
        while True:
            ws = None
            try:
                ws = await websockets.connect(origin, ping_interval=20, ping_timeout=20)
                first = json.loads(await asyncio.wait_for(ws.recv(), timeout=15))
                if first.get('metadata', {}).get('message_type') != 'session_welcome':
                    raise RuntimeError('Expected Twitch session_welcome')
                session = first['payload']['session']['id']
                log.info('TWITCH WELCOME: new session %s', session[-8:])
                await self.subscribe(session)
                log.info('TWITCH SOCKET READY: subscriptions attached to %s', session[-8:])

                while True:
                    raw = await ws.recv()
                    packet = json.loads(raw)
                    kind = packet.get('metadata', {}).get('message_type')
                    if kind == 'session_notification':
                        event_type = packet.get('payload', {}).get('subscription', {}).get('type', '')
                        if event_type == 'channel.chat.message':
                            self.chat_debug_count = getattr(self, 'chat_debug_count', 0) + 1
                            if self.chat_debug_count == 1 or self.chat_debug_count % 100 == 0:
                                log.info('CHAT MONITOR: %s messages received', self.chat_debug_count)
                        await self.notification(packet)
                    elif kind == 'session_reconnect':
                        url = packet['payload']['session']['reconnect_url']
                        log.info('TWITCH RECONNECT: opening replacement before closing old session')
                        replacement = await websockets.connect(url, ping_interval=20, ping_timeout=20)
                        try:
                            welcome = json.loads(await asyncio.wait_for(replacement.recv(), timeout=15))
                            if welcome.get('metadata', {}).get('message_type') != 'session_welcome':
                                raise RuntimeError('Reconnect socket did not send session_welcome')
                        except Exception:
                            await replacement.close()
                            raise
                        # Twitch migrates subscriptions automatically onto reconnect URLs.
                        await ws.close()
                        ws = replacement
                        log.info('TWITCH RECONNECTED: subscriptions retained')
                    elif kind == 'session_keepalive':
                        log.debug('Twitch keepalive received')
                    elif kind == 'revocation':
                        log.error('Subscription revoked: %s', packet['payload'])
                    else:
                        log.debug('Other Twitch WebSocket message type: %s', kind)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.error('WebSocket error: %s; reconnecting with fresh subscriptions', e)
                await asyncio.sleep(5)
            finally:
                if ws is not None:
                    await ws.close()

    async def periodic_check(self):
        while True:
            await asyncio.sleep(10)
            self.expire_highlight(time.time())
            try:
                if int(time.time()) % 300 < 10: await self.check_live()
            except Exception as e: log.warning('Live check failed: %s', e)

    async def start(self):
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=25)) as http:
            self.http = http
            await self.setup()
            await asyncio.gather(self.run_socket(), self.periodic_check(), self.session_report_loop())

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    asyncio.run(Bot().start())
