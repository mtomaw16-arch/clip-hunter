# Clip Hunter v9 — sequential Twitch titles + Discord explanations

**Upgrade from v7 in-place.** The main additions to v8 are the Twitch titles `Sketch - 001`, `Sketch - 002`, etc. The counter resets for each new stream session and is stored in SQLite to survive bot restarts. Failed/unconfirmed clip requests may cause missing numbers, deliberately preventing duplicate titles. The title is passed as the `title` parameter to Twitch's Create Clip endpoint.

Discord `#all-clips` embeds show the clip title, trigger, score, chat rate, keyword-family matches, number of distinct keyword viewers, and trigger time. `#top-clips` groups an ongoing event into one editable message. `#daily-reports` sends a per-stream recap **five minutes after the bot detects stream offline**, rather than at a set time of day. If offline detection is delayed, the report is delayed.

## Safe in-place Hostinger upgrade from installed v7

The VPS was configured with `/opt/clip-hunter/clip_hunter_v7` as the service's `WorkingDirectory`. **Keep that directory.** Only `bot.py` and `store.py` need replacing; both are included in this upgrade-only ZIP. Your existing `.env`, `tokens.json`, `.venv`, `clips.db`, Discord secrets, and `clip-hunter.service` are not included and must not be overwritten.

Upload `clip_hunter_v9_upgrade.zip` to the **root** of your existing GitHub repo (`mtomaw16-arch/clip-hunter`), commit it, then in the Hostinger web console run:

```bash
cd /opt/clip-hunter
git pull --ff-only
cd clip_hunter_v7
cp bot.py bot.py.before_v9
cp store.py store.py.before_v9
unzip -o ../clip_hunter_v9_upgrade.zip bot.py store.py
.venv/bin/python -m py_compile bot.py store.py
.venv/bin/python -m unittest test_detection -v
```

Do not paste credentials into the terminal or GitHub. Do **not** restart the bot until Twitch OAuth authentication is complete; after authentication, restart using `systemctl restart clip-hunter`. Your `.env` should retain `DRY_RUN=false` when you intend real clipping. The bot requires a valid `tokens.json` before it can run. If it is enabled but missing Twitch authentication, disable it temporarily with `systemctl disable --now clip-hunter` to avoid restart loops.

## Limitations

- This is a code-level/local test update; Twitch clips have not been tested live.
- Twitch's live Create Clip API supports an optional `title` parameter and `duration` up to 60 seconds, but cannot guarantee an exact 45-second-before/15-second-after cut with a regular viewer account.
- A viewer still needs Twitch authorization with `clips:edit` and `user:read:chat`; no permission to post chat or purchase anything is requested.
- Protect your Discord webhooks, app credentials, and `tokens.json`.
