import os, sqlite3
from pathlib import Path
from dotenv import load_dotenv
load_dotenv()
DB_PATH = Path(os.getenv('CLIP_DB', 'clips.db'))
def connect():
    db=sqlite3.connect(DB_PATH,timeout=15)
    db.row_factory=sqlite3.Row
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('''CREATE TABLE IF NOT EXISTS clips (id INTEGER PRIMARY KEY, ts TEXT DEFAULT CURRENT_TIMESTAMP, reason TEXT, score INTEGER, clip_id TEXT, url TEXT, status TEXT, edit_url TEXT)''')
    existing={row[1] for row in db.execute('PRAGMA table_info(clips)')}
    for field,kind in [('group_id','INTEGER'),('thumbnail_url','TEXT'),('reviewed','INTEGER DEFAULT 0'),('discord_status',"TEXT DEFAULT 'pending'"),('spike_ratio','REAL'),('keyword_users','INTEGER'),('trigger_words','TEXT'),('posted','INTEGER DEFAULT 0'),('platform','TEXT'),('post_url','TEXT'),('views','INTEGER DEFAULT 0'),('earnings','REAL DEFAULT 0'),('notes','TEXT'),('triggered_at','TEXT'),('clip_title','TEXT'),('clip_number','INTEGER'),('stream_session_id','INTEGER')]:
        if field not in existing:db.execute(f'ALTER TABLE clips ADD COLUMN {field} {kind}')
    db.execute('CREATE INDEX IF NOT EXISTS idx_clips_time ON clips(ts)')
    db.execute('CREATE TABLE IF NOT EXISTS app_state (key TEXT PRIMARY KEY, val TEXT)')
    db.execute('''CREATE TABLE IF NOT EXISTS highlights (
        id INTEGER PRIMARY KEY, created_at TEXT DEFAULT CURRENT_TIMESTAMP, ended_at TEXT,
        best_score INTEGER DEFAULT 0, discord_message_id TEXT, status TEXT DEFAULT 'active',
        last_signal REAL DEFAULT 0)''')
    db.execute('''CREATE TABLE IF NOT EXISTS stream_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT, started_at TEXT NOT NULL, ended_at TEXT,
        report_due_at TEXT, report_sent_at TEXT, status TEXT NOT NULL DEFAULT 'live'
    )''')
    db.execute('''CREATE TABLE IF NOT EXISTS clip_sequences (
        session_id INTEGER PRIMARY KEY, last_number INTEGER NOT NULL DEFAULT 0)''')
    db.execute('CREATE INDEX IF NOT EXISTS idx_stream_sessions_due ON stream_sessions(report_due_at,report_sent_at)')
    db.execute('CREATE TABLE IF NOT EXISTS event_log (id INTEGER PRIMARY KEY, ts TEXT DEFAULT CURRENT_TIMESTAMP, event_type TEXT, description TEXT)')
    db.commit()
    return db
